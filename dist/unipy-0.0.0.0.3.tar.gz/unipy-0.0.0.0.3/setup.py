from setuptools import setup, find_packages


long_desc = """
This is made for some specific environment.
This contains codes for data manipulation and Analysis tools.
"""

setup(name='unipy',
      version='0.0.0.0.03',
      description='Useful tools for Data Scientists',
      long_description=long_desc,
      url='http://github.com/pydemia',
      author='Young Ju Kim',
      author_email='pydemia@gmail.com',
      license='MIT License',
      classifiers=[
            # How Mature: 3 - Alpha, 4 - Beta, 5 - Production/Stable
            'Development Status :: 3 - Alpha',
            'Environment :: Console',
            'Programming Language :: Python :: 3.5',
            'Operating System :: OS Independent',
            'Intended Audience :: End Users/Desktop',
            'Intended Audience :: Developers',
            'Intended Audience :: Science/Research',
            'Natural Language :: English',
            ],
      packages=find_packages(exclude=['contrib', 'docs', 'tests']),
      install_requires=[
                        'pandas', 'numpy', 'scipy', 'statsmodels',
                        'pymysql', 'psycopg2', 'sqlalchemy',
                        'ibm_db_sa'
                        # 'cx_Oracle'
                        ],
      zip_safe=False)
