# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 20:55:26 2017

@author: Young Ju Kim
"""

#%% Sample datasets

from unipy.sample.datasets import dataManager

dataManager.datalist()
wine1 = dataManager.load('wine1')
wine2 = dataManager.load('wine2')

#%% VIF

from unipy.statsmod.multivariates import feature_selection_vif as fsv

res, lst = fsv(wine1, thresh=5.0)

