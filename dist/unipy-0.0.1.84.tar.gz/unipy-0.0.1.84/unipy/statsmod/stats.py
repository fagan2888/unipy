import numpy as np
import pandas as pd
import scipy.stats as st


def deviation(container, method='mean', if_abs=True):

    if method == 'mean':
        center = np.nanmean(container)
    elif method == 'median':
        center = np.nanmedian(container)

    resIter = map(lambda x: x - center, container)

    if if_abs == True:
        resIter = map(np.absolute, resIter)

    res = np.fromiter(resIter, dtype=np.float)

    return res


