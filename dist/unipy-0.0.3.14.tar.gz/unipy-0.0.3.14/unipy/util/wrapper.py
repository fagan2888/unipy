# -*- coding: utf-8 -*-
"""
Created on Tue May 30 10:33:36 2017

@author: Young Ju Kim
"""


from datetime import datetime as dt
from functools import wraps

__all__ = ['time_profiler']


def time_profiler(func):

    @wraps(func)
    def profiler(*args, **kwargs):

        start_tm = dt.now()
        print("JobStart :", start_tm)

        res = func(*args, **kwargs)

        end_tm = dt.now()
        print("JobEnd   :", end_tm)

        elapsed_tm = end_tm - start_tm
        print("Elapsed  :", elapsed_tm)

        return res

    return profiler



def job_wrapper(func, jobname):

    @wraps(func)
    def wrapper(*args, **kwargs):

        # Message Length = 40 + 2 (\n)
        dash_len = int((40 - len(jobname) - 12) / 2)
        
        start_msg = '-'*dash_len + ' [ {} ] START ' + '-'*dash_len + '\n'
        print(start_msg)

        res = func(*args, **kwargs)

        end_msg = '-'*dash_len + '  [ {} ] END  ' + '-'*dash_len + '\n'
        print(end_msg)
        
        return res

    return wrapper


