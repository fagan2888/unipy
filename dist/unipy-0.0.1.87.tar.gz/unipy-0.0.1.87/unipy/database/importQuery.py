# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 20:55:26 2017

@author: Young Ju Kim
"""

import pandas as pd
from datetime import datetime

import psycopg2 as pg
import sqlalchemy as sa
# import ibm_db
# import ibm_db_sa
import cx_Oracle as co
import pymysql


from unipy.util.base import time_profiler

@time_profiler
def to_MariaDB(dataframe, name=None, h=None, port=None, db=None, u=None, p=None,
            if_exists='append'):

    print('Using MariaDB')

    # DB Connection
    connStr = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'
    engine = sa.create_engine(connStr.format(u, p, h, str(port), db))
    conn = engine.connect()
    start_tm = datetime.now()
    print(' Start :', str(start_tm))

    # Get a DataFrame
    dataframe.to_sql(con=conn, name=None, if_exists=if_exists,
                     flavor='mysql', index=False, chunksize=None)

    # Close Connection
    end_tm = datetime.now()
    print(' Finish :', str(end_tm))
    print('Elapsed :', str(end_tm - start_tm))
    conn.close()
