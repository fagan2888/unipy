#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 30 17:05:27 2017

@author: dawkiny
"""

import itertools as it
import multiprocessing as mpr

__all__ = ['split_generator',
           'exceptor',
           'multiprocessor']


def split_generator(iterable, size):

    data = iter(iterable)
    item = list(it.islice(data, size))

    while item:
        yield item
        item = list(it.islice(data, size))


def exceptor(x, exceptlist):
    
    res = [member for member in x if member not in exceptlist]
    
    return res
   


def multiprocessor(func, processes=2, arg_zip=None, *args, **kwargs):

    pool = mpr.pool.Pool(processes=processes)
    resp = pool.starmap(func, arg_zip, *args, **kwargs)

    return resp 
###
# list(filter(lambda col: col not in ['capital_gain'], test.columns))
# [member for member in test.columns if member not in ['capital_gain']]
