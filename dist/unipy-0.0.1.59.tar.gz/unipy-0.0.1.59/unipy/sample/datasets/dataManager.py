# -*- coding: utf-8 -*-
"""
Created on Sun Jan  8 05:03:19 2017

@author: Young Ju Kim
"""

import pandas as pd
import tarfile
import os
from os.path import dirname, abspath


def init():
    filepath = dirname(abspath(__file__))
    filename = filepath + '/resources.tar.gz'
    tar = tarfile.open(filename)
    filelist = list(set(map(lambda x: x.split('/')[0], tar.getnames())))
    tar.extractall(filepath)
    tar.close()
    print(filelist)


def reset():
    filepath = dirname(abspath(__file__))
    filename = filepath + '/resources.tar.gz'
    tar = tarfile.open(filename)
    tar.extractall(filepath)
    tar.close()


def ls():

    filepath = dirname(abspath(__file__))
    filename = filepath + '/resources.tar.gz'
    tar = tarfile.open(filename)
    filelist = list(set(map(lambda x: x.split('/')[0], tar.getnames())))
    dirclist = os.listdir()
    datalist = list(filter(lambda x: x in filelist, dirclist)) 
    datalist.sort()

    return datalist


def load(pick):

    filepath = dirname(abspath(__file__))
    dataname = pick

    if type(pick) is str:
        datafile = filepath + '/{dataset}/{dataset}.data'.format(dataset=dataname)
        data = pd.read_csv(open(datafile, 'rb'), sep=",")

    elif type(pick) is int:
        filename = filepath + '/resources.tar.gz'
        tar = tarfile.open(filename)
        filelist = list(set(map(lambda x: x.split('/')[0], tar.getnames())))
        dirclist = os.listdir()
        datalist = list(filter(lambda x: x in filelist, dirclist)) 
        datalist.sort()
        
        dataname = datalist[pick]
        datafile = filepath + '/{dataset}/{dataset}.data'.format(dataset=dataname)
        data = pd.read_csv(open(datafile, 'rb'), sep=",")

    return data

