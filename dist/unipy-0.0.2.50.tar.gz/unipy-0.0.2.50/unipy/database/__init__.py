# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 20:55:26 2017

@author: Young Ju Kim
"""


from unipy.database import select_query
from unipy.database import insert_query

from unipy.database.select_query import *
from unipy.database.insert_query import *

__all__ = []
__all__ += select_query.__all__
__all__ += insert_query.__all__

