# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 20:55:26 2017

@author: Young Ju Kim
"""


#%% Sample datasets
import unipy.data as dm

# Extract Datasets for the first time
dm.init()

# Reset Datasets
dm.reset()

# Get a Dataset list
dm.datalist()

# Load Datasets
wine1 = dm.load('winequality_red')
wine2 = dm.load('winequality_white')

#%% VIF

from unipy.statsmod.multivariates import feature_selection_vif as fsv

res, drp = fsv(wine1, thresh=5.0)
